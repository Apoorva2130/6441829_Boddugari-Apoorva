const eventName = "Music Night";
const eventDate = "2025-06-15";
let seats = 100;
console.log(`Event: ${eventName} on ${eventDate}, Seats left: ${seats}`);
seats--;
console.log(`Seats left after registration: ${seats}`);